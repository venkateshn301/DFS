CREATE TABLE IF NOT EXISTS dmd_staging.brightedge_keywordgroup_revenue
(
  search_engine character varying(255),
  keywordgroup character varying(255),
  revenue character varying(255),
  domain character varying(255),
  "time" character varying(100),
  accountid character varying(255)
);


