CREATE TABLE IF NOT EXISTS dmd_staging.brightedge_keywordgroup_mappings
(
  name character varying(255),
  id character varying(255),
  keywordgroup_id character varying(255),
  keywordgroup character varying(255),
  accountid character varying(255)
);
