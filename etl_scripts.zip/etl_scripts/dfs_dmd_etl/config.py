
schema = 'dmd_staging'
'''BrightEdge'''

br_username = 'anthony.beresford@beyondanalysis.net'
br_password = 'D0k15MZsZSiZy27HWpg3'

'''file path to csv files'''
br_file_path = ''
base_url = 'https://api.brightedge.com/3.0/'
br_connection_string = "host='localhost' port='5432' dbname='test' user='masteruser' password='masteruser'"

"""Criteo"""

cr_username = 'london@beyondanalysis.net'
cr_password = 'SNJeMYPgE3goi7xjxRfS!'
cr_token = '1844883410860426752'
cr_connection_string = 'postgresql://masteruser:masteruser@localhost/test'