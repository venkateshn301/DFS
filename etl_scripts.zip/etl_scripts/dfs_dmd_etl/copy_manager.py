import psycopg2


def csv_to_postgres(conn, cur, filename, tablename):

    f = open(filename, 'r')
    SQL_STATEMENT = """COPY %s FROM STDIN WITH CSV HEADER DELIMITER AS ','"""

    try:
        cur.copy_expert(sql=SQL_STATEMENT % tablename, file=f)
        conn.commit()
        result = 'Success'

    except (psycopg2.IntegrityError, psycopg2.ProgrammingError) as err:
        result = err

    return result
