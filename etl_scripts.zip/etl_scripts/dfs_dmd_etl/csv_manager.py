import os.path
import pandas as pd


def dump_csv(filename, data):

    df = pd.DataFrame(data)
    try:
        if os.path.isfile(filename):
            df.to_csv(filename, index=False, mode='a', header=False)
        else:
            df.to_csv(filename, index=False)

        result = 'Success'
    except:

        result = 'Error occured while copying data to csv'

    return result
