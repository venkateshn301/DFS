-- products ranges reference table to support range wise search performance

drop view if exists dmd_integration.products;

create view dmd_integration.products as
select p.dfsproductcode,p.rangecode,r.range_name from ddd_staging.products p
inner join ddd_staging.pldata_ranges r on p.rangecode = r.range_code;

-- search campaigns reference to maintain campaign id to campaign labels.
-- This will be used for products advertised reporting on DS Api.

drop view if exists dmd_integration.search_campaigns;

create view dmd_integration.search_campaigns as
select campaignid, campaign as campaignname, effectivelabels as campaignlabels, campaignstatus
from dmd_staging.doubleclick_search_campaign
group by 1, 2, 3, 4;

-- search performance by product ranges

drop table if exists dmd_integration.products_search_performance_by_product_range CASCADE;

create table dmd_integration.products_search_performance_by_product_range as
    select date
    ,c.campaignlabels as camapaignabel
    , p.range_name,sum(impr)as tot_impr
    , sum(clicks)as tot_clicks
    , sum(cost) as tot_cost
    , avg(ctr) as avg_ctr
    , sum(revenue) as tot_revenue
    , sum(sales) as total_sales
    , sum(storelocator) as tot_storevisits
    , sum(allconversions) as tot_conversions
    from dmd_staging.doubleclick_search_products sp
    inner join dmd_integration.products p on sp.productid = p.dfsproductcode
    inner join dmd_integration.search_campaigns c on sp.campaignid = c.campaignid
    where sp.campaignid is not null
    group by 1, 2, 3;

-- search overview

drop table if exists dmd_integration.search_overview;

create table dmd_integration.search_overview as 
select date
    , account
    , effectivelabels as campaignlabel
    , sum(impr) as tot_impr
    , sum(cost) as tot_cost
    , avg(avgpos) as avg_pos
    , avg(avgcpc) as avg_cpc
    , sum(visits) as tot_visits
    , sum(clicks) as tot_clicks
    , sum(cmbs) as tot_cmbs
    , sum(calls) as tot_calls
    , sum(sales) as tot_saleconversions
    , sum(allconversions) as tot_allconversions
    , sum(adwordsconversions) as tot_adwordsconversions 
    , sum(uniquelands) as tot_uniquelands
    , sum(storelocator) as tot_storevisits
    , avg(aov) as avg_ordervalue
    , sum(revenue) as tot_ecomrevenue
    , avg(case when searchimpressionshare not like '%<%' then cast(searchimpressionshare as float8) end ) as avg_searchimpressionsshare
    , sum(videochats) as tot_videochats
    from dmd_staging.doubleclick_search_campaign
    group by 1, 2, 3;

-- daily visits by each source channels. i.e. SEO, CPC, Display and Retargeting

drop table if exists dmd_integration.daily_visits_by_sources CASCADE;

create table dmd_integration.daily_visits_by_sources as
select date
,sum(totalpageviews) filter(where device in ('mobile')) as totalmobilepageviews
,sum(totalpageviews) filter(where device in ('desktop','tablet')) as totaldesktoppageviews
,sum(totalvisits) filter(where device in ('mobile')) as totalmobilevisits
,sum(totalvisits) filter(where device in ('desktop','tablet')) as totaldesktopvisits
,sum(totalnewvisits) filter(where device in ('mobile')) as totalmobilenewvisits
,sum(totalnewvisits) filter(where device in ('desktop','tablet')) as totaldesktopnewvisits
,sum(totalvisits) filter(where effectivesource = 'Retargeting') as totalretargetingvisits
,sum(totalvisits) filter(where effectivesource = 'SEO') as totalseovisits
,sum(totalvisits) filter(where effectivesource = 'Paid Search') as totalpaidsearchvisits
,sum(totalvisits) filter(where effectivesource = 'Display') as totaldisplayvisits
,sum(totalvisits) filter(where effectivesource = 'Other') as totalothervisits
,sum(totalvisits) filter(where effectivesource = 'Retargeting' and device in ('desktop','tablet') ) as totaldesktopretargetingvisits
,sum(totalvisits) filter(where effectivesource = 'SEO' and device in ('desktop','tablet')) as totaldesktopseovisits
,sum(totalvisits) filter(where effectivesource = 'Paid Search' and device in ('desktop','tablet')) as totaldesktoppaidsearchvisits
,sum(totalvisits) filter(where effectivesource = 'Display' and device in ('desktop','tablet')) as totaldesktopdisplayvisits
,sum(totalvisits) filter(where effectivesource = 'Other' and device in ('desktop','tablet')) as totaldesktopothervisits
,sum(totalvisits) filter(where effectivesource = 'Retargeting' and device in ('mobile') ) as totalmobileretargetingvisits
,sum(totalvisits) filter(where effectivesource = 'SEO' and device in ('mobile')) as totalmobileseovisits
,sum(totalvisits) filter(where effectivesource = 'Paid Search' and device in ('mobile')) as totalmobilepaidsearchvisits
,sum(totalvisits) filter(where effectivesource = 'Display' and device in ('mobile')) as totalmobiledisplayvisits
,sum(totalvisits) filter(where effectivesource = 'Other' and device in ('mobile')) as totalmobileothervisits
,sum(totaltransactions) filter(where effectivesource in ('SEO')) as totalseoconversions
,sum(totaltransactionsrevenue) filter(where effectivesource in ('SEO')) as totalseorevenue
,sum(totaltransactionsrevenue) filter(where effectivesource in ('Paid Search')) as totalcpcrevenue
from 
(select *,(case when source = 'criteo' then 'Retargeting'
               when medium = 'cpc' then 'Paid Search'
               when medium = 'organic' then 'SEO'
               when medium = 'display' and source <> 'criteo' then 'Display' -- need to check email, social, chat, referrel
               else 'Other' end) as effectivesource
  from dmd_staging.gapremium_daily_visits where country in ('uk') -- only taking uk as DMD reports only on UK
) visits
group by 1;

-- display and direct campaigning

drop view if exists dmd_integration.display_performance CASCADE;

create view dmd_integration.display_performance as
select *
from dmd_staging.doubleclick_display_uk;
-- union
-- select *
-- from dmd_staging.doubleclick_email
-- union
-- select *
-- from dmd_staging.doubleclick_social