-- search performance to report agains campaign and keyword

drop table if exists dmd_dwh.search_performance;

create table dmd_dwh.search_performance as
select date
, effectivecampaignlabel as campaignlabel
, sum(tot_impr) filter( where account in ('Google UK')) as tot_googleimpr
, sum(tot_impr) filter( where account in ('Bing UK')) as tot_bingimpr
, avg(avg_cpc) filter( where account in ('Google UK')) as avg_googlecpc
, avg(avg_cpc) filter( where account in ('Bing UK')) as avg_bingcpc 
, avg(avg_pos) filter( where account in ('Google UK')) as avg_googlepos
, avg(avg_pos) filter( where account in ('Bing UK')) as avg_bingpos
, avg(avg_searchimpressionsshare) filter( where account in ('Google UK')) as avg_googleimprshare
, avg(avg_searchimpressionsshare) filter( where account in ('Bing UK')) as avg_bingimprshare
, sum(tot_clicks) filter( where account in ('Google UK')) as tot_googleclicks
, sum(tot_clicks) filter( where account in ('Bing UK')) as tot_bingclicks
, sum(tot_visits) as tot_visits
, sum(tot_calls) as tot_calls
, sum(tot_cmbs) as tot_cmbs
, sum(tot_videochats) as tot_videochats
, sum(tot_storevisits) as tot_storevisits
, sum(tot_ecomrevenue) as tot_ecomrevenue
, sum(tot_saleconversions) as tot_saleconversions
, sum(tot_allconversions) as tot_allconversions
from (
select 
 *,
 case when campaignlabel in ('Shopping') then 'Shopping'
      when campaignlabel in ('Competitors') then 'Competitors'
      when campaignlabel in ('Brand') then 'Brand'
      when campaignlabel in ('Generics') then 'Generic'
      else 'Other' end as effectivecampaignlabel
 from dmd_integration.search_overview
) s
group by 1,2;

-- display performance to report by campaign and patner type

drop table if exists dmd_dwh.display_performance;

create table dmd_dwh.display_performance as
select d.date
, campaigntype as campaign
, partner
, sum(impr) as tot_impr
, sum(clicks) as tot_clicks
, avg(cpc) as avg_cpc
, sum(cmbs) as tot_cmbs
, sum(uniquelands) as tot_uniquelands
, sum(totalconversions) as tot_conversions
, sum(onlineconversions) as tot_onlineconversions
, sum(totalrevenue) as tot_revenue
, max(call_count) as tot_campaign_calls
from
(select *
, case when site in ('Criteo.co.uk') then 'Retargeting' --currently using criteo and criteo only as Retargeting
               else 'Direct' end as campaigntype
, case when site in ('AOL Uk') then 'AOL'
       when site in ('Media IQ') then 'MediaIQ'
       when site in ('AppNexus', 'GMSM') and lower(placement) like '%always%' then 'PBU'
       else null end as partner        
from dmd_integration.display_performance) d
left outer join dmd_integration.display_campaign_call_count c on d.date = c.date and d.campaigntype = c.campaign
group by 1, 2, 3;

-- product performance for paid search

drop view if exists dmd_dwh.product_performance;

create view dmd_dwh.product_performance as
select * from dmd_integration.products_search_performance_by_product_range;

-- daily visits by search engine type and source channels 

drop view if exists dmd_dwh.visits_by_sources;

create view dmd_dwh.visits_by_sources as
select * from dmd_integration.daily_visits_by_sources;