#!/bin/bash

PSQL='psql -h dev-extractor-db.cnimcclfnoqr.eu-west-1.rds.amazonaws.com -p 5432 -U masteruser -d extractordb -e -v ON_ERROR_STOP=1 -1 '
$PSQL -f integration.sql
$PSQL -f dwh.sql