import sys
import requests
import json
import psycopg2
from datetime import datetime
import config
import csv_manager as csv
from copy_manager import csv_to_postgres as c2p
import brightedge.data_dict as datadict

#execute file inside dfs_dmd_etl as python -c "import brightedge.brightedge_api as b;b.retrieve_data('keyword_rank_data', '20171022', '20171029')"
#TODO add credentials to environment variables
auth = (config.br_username, config.br_password)
base_url = config.base_url


try:
    conn = psycopg2.connect(config.br_connection_string)
    cur = conn.cursor()

except psycopg2.OperationalError as err:
    print(err)


def date_filter(start_date=None, end_date=None):

    if start_date and end_date:

        start_date = datetime.strptime(start_date, '%Y%m%d')
        end_date = datetime.strptime(end_date, '%Y%m%d')
        fltr = (["time", "ge", start_date.strftime("%Y%U")], ["time", "le", end_date.strftime("%Y%U")])

    elif start_date:

        start_date = datetime.strptime(start_date, '%Y%m%d')
        fltr = ([["time", "ge", start_date.strftime("%Y%U")]])

    else:

        fltr = ([["time", "eq", datetime.now().strftime("%Y%U")]])

    return fltr


def execute_sql(cur, sql_query):

    cur.execute(sql_query)
    current = cur.fetchall()

    return current


def csv_to_postgres(cur, filename, tablename):

    f = open(filename, 'r')
    SQL_STATEMENT = """COPY %s FROM STDIN WITH CSV HEADER DELIMITER AS ','"""

    try:
        cur.copy_expert(sql=SQL_STATEMENT % tablename, file=f)
        conn.commit()
        result = 'Success'

    except (psycopg2.IntegrityError, psycopg2.ProgrammingError) as err:
        result = err

    return result


def getAccountids(cur, schema):

    return execute_sql(cur, """SELECT * from %s.brightedge_account_details""" % schema)


def form_filename(table_name, start_date=None, end_date=None):

    if start_date and end_date :
        file_name = start_date + '_' + end_date + '.csv'
    elif end_date:
        file_name = start_date + '.csv'
    else:
        file_name = datetime.now().strftime("%Y%m%d")+'.csv'

    return config.br_file_path + table_name + '_' + file_name


def get_request(url, file_name, key):

    r = requests.get(url, auth=auth)

    if r.status_code == 200:
        data = r.json()[key]
        result = csv.dump_csv(file_name, data)

    else:
        result = r.status_code

    return result


def post_request(url, query, file_name, account_id, key, start_date, end_date):

    i = 0
    total = count = 1000
    while i <= total:

        query["offset"] = '{0}'.format(i)
        query["filter"] = list(date_filter(start_date, end_date))
        print(list(query["filter"]))
        d = 'query={0}'.format(json.dumps(query))
        print(url)
        r = requests.post(url, auth=auth, data=d)

        if r.status_code == 200:
            response = r.json()[key]
            if response:
                for k in response:
                    k.update({"accountid": account_id})

                csv.dump_csv(file_name, response)
                total = r.json()["total"]
                i = i + count

                result = 'Success'
            else:
                result = 'No Data retrived'
                break
        else:
            result = r.status_code

    return result


def retrieve_data(dict_name, start_date=None, end_date=None):

    init_dict = getattr(datadict, dict_name)
    url = config.base_url + init_dict['url']
    table_name = config.schema + '.' + init_dict['tablename']
    file_name = form_filename(table_name, start_date, end_date)

    if init_dict['type'] == 'get':
        data = get_request(url, file_name, init_dict['key'])

    elif init_dict['type'] == 'post':
        query = init_dict["query"]

        for row in getAccountids(cur, config.schema):
            account_id = row[1]
            acc_url = url + str(account_id)
            data = post_request(acc_url, query, file_name, account_id, init_dict['key'], start_date, end_date)

    else:
        data = 'Request Method not implemented yet.'

    if data == 'Success':
        result = c2p(conn, cur, file_name, table_name)
    else:
        result = data

    print(result)
