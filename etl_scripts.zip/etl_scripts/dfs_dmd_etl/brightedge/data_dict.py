"""Add queries to get data from brightedge api"""

account_details = {

    "tablename" : "brightedge_account_details",
    "type"      : "get",
    "url"       : "objects/accounts",
    "key"       : "accounts",
    "query"     : ""
}

domain_details = {

    "tablename" : "brightedge_domain_details",
    "type"      : "get",
    "url"       : "objects/domains",
    "key"       : "domains",
    "query"     : ""
}

keyword_rank_data = {

    "tablename" : "brightedge_keyword_rank",
    "type"      : "post",
    "url"       : "query/",
    "key"       : "values",
    "query"     : {
                    "dataset"           : "keyword",
                    "dimension"         : ["keyword", "domain", "time", "search_engine"],
                    "measures"          : ["rank"],
                    "dimensionOptions"  : {"time": "weekly"},
                    "order"             : [["rank", "asc"]],
                    "count"             : "1000"
    }
}

keywordgroup_revenue ={

    "tablename" : "brightedge_keywordgroup_revenue",
    "type"      : "post",
    "url"       : "query/",
    "values"    : "values",
    "query"     : {
                    "dataset"           : "keywordgroup",
                    "dimension"         : ["keywordgroup", "domain", "time", "search_engine"],
                    "measures"          : ["revenue"],
                    "dimensionOptions"  : {"time": "weekly"},
                    "order"             : [["revenue", "desc"]],
                    "count"             : "1000"

    }
}
