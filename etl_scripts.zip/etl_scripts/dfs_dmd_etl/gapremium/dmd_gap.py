import argparse
import httplib2
import pprint
import io
import os
import sys
from time import strftime
from datetime import date, timedelta
import dmd_gap_setup
import dmd_gap_config
from googleapiclient import http
from apiclient.discovery import build
from oauth2client import GOOGLE_TOKEN_URI
from oauth2client.client import OAuth2Credentials

from apiclient.errors import HttpError
from oauth2client.client import AccessTokenRefreshError


def runSyncQuery(service, projectId, datasetId, query_type, date_start, date_end, results_path):
    timeout = 0
    try:
        jobCollection = service.jobs()
        queryData = {'timeoutMs': timeout}

        query_string = dmd_gap_config.get_sql(query_type, date_start, date_end)

        queryData.update({'query': str(query_string)})

        queryReply = jobCollection.query(projectId=projectId,
                                         body=queryData).execute()

        jobReference = queryReply['jobReference']

        # Timeout exceeded: keep polling until the job is complete.
        while(not queryReply['jobComplete']):
            pprint.pprint('Job not yet complete.')
            queryReply = jobCollection.getQueryResults(
                projectId=jobReference['projectId'], jobId=jobReference['jobId'], timeoutMs=timeout).execute()

            # If the result has rows, print the rows in the reply.
        fo = open(results_path, 'w')
        if('rows' in queryReply):
            print('Rows Returned ',  len(queryReply['rows']))
            print('Total Rows ', queryReply['totalRows'])
            currentRow = 0

            # Loop through each page of data
        while('rows' in queryReply and currentRow < int(queryReply['totalRows'])):
            queryReply = jobCollection.getQueryResults(
                projectId=jobReference['projectId'], jobId=jobReference['jobId'], startIndex=currentRow).execute()
            if('rows' in queryReply):
                for row in queryReply['rows']:
                    result_row = []
                    for field in row['f']:
                        if field['v'] == None:
                            result_row.append('')
                        else:
                            result_row.append(field['v'].replace('|', ''))
                        # print ('\t').join(result_row).encode('utf-8')
                    print(('|').join(result_row))
                    try:
                        fo.write(('|').join(result_row))
                    except:
                        raise
                    fo.write('\n')
                currentRow += len(queryReply['rows'])
        fo.close()
    except AccessTokenRefreshError:
        pprint.pprint(
            "The credentials have been revoked or expired, please re-run the application to re-authorize")

    except HttpError as err:
        pprint.pprint('Error in runSyncQuery:', err.content)

    except Exception as err:
        raise


if __name__ == '__main__':
    dafault_date = (date.today() - timedelta(1)).strftime("%Y-%m-%d")
    parser = argparse.ArgumentParser(description='Sample DS API code.')
    parser.add_argument('--query_type', dest='query_type', action='store',
                        help=('Specifies the Big Query query type. E.g. dailyAggreates'), default='dailyAggregates')
    parser.add_argument('--date_start', dest='date_start', action='store',
                        help=('Specifies the start date for the query. This will be part of the daily sessions tables id. E.g. 2017-11-15'), default=dafault_date)
    parser.add_argument('--date_end', dest='date_end', action='store',
                        help=('Specifies the end date for the query. This will be part of the daily sessions tables id. E.g. 2017-11-20'), default=dafault_date)
    args = parser.parse_args()
    service = dmd_gap_setup.setup(None)
    runSyncQuery(service, dmd_gap_config.GA_PROJECT_ID,
                 dmd_gap_config.GA_DATASET_ID, args.query_type, args.date_start, args.date_end, args.query_type + '.csv')
