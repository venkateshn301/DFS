"""
Configuration for GA Premium 360.
"""

__QUERIES_BY_TYPE__ = {
    "dailyAggregatesFull": """
        SELECT
            date,
            country,
            device,
            medium,
            source,
            SUM(transactions) AS total_transactions,
            SUM(transactionRevenue) / 1000000 AS total_transactions_revenue,
            SUM(timeOnSite) / (60) AS total_time,
            SUM(bounces) AS total_bounces,
            SUM(hits) AS total_hits,
            SUM(pageviews) AS total_pageviews,
            SUM(newVisits) AS total_newvisits,
            SUM(visits) AS total_visits
            FROM (
            SELECT
                CONCAT(SUBSTR(date,0,4),"-",SUBSTR(date,5,2),"-",SUBSTR(date,7,2)) AS date,
                visitId,
                fullVisitorId,
                trafficSource.medium AS medium,
                trafficSource.source AS source,
                FIRST(CASE
                    WHEN (hits.page.hostname CONTAINS 'dfs.ie') THEN 'ie'
                    WHEN (hits.page.hostname CONTAINS 'dfs.co.uk') THEN 'uk'
                    WHEN (hits.page.hostname CONTAINS 'dfs-banken.nl') THEN 'nl' END) AS country,
                FIRST(device.deviceCategory) AS device,
                MAX(totals.transactions) AS transactions,
                MAX(totals.transactionRevenue) AS transactionRevenue,
                MAX(totals.timeOnSite) AS timeOnSite,
                MAX(totals.bounces) AS bounces,
                MAX(totals.hits) AS hits,
                MAX(totals.pageviews) AS pageviews,
                MAX(totals.newVisits) AS newVisits,
                MAX(totals.visits) AS visits
          FROM (TABLE_DATE_RANGE([{ga_project_id}:{ga_dataset_id}.{ga_sessions_table_prefix}], TIMESTAMP('{date_start}'), TIMESTAMP('{date_end}')))
          GROUP BY
            1,
            2,
            3,
            4,
            5 )
        GROUP BY
            date,
            country,
            device,
            medium,
            source
    """,
    "dailySessionInfo": """
    SELECT
      CONCAT(SUBSTR(date,0,4),"-",SUBSTR(date,5,2),"-",SUBSTR(date,7,2)) AS date,
      visitNumber,
      visitId,
      fullVisitorId,
      trafficSource.referralPath,
      trafficSource.campaign,
      trafficSource.source,
      trafficSource.medium,
      trafficSource.keyword,
      trafficSource.adContent,
      
      device.isMobile,
      device.deviceCategory,

      totals.transactions,
      totals.transactionRevenue,
      totals.timeOnSite,
      totals.bounces,
      totals.hits,
      totals.pageviews,
      totals.newVisits,
      totals.visits,
      
      hits.type,
      hits.hitNumber,
      hits.isInteraction,
      hits.referer,
      hits.page.pagePath,
      hits.page.hostname,
      hits.page.pageTitle,
      hits.page.searchKeyword,
      hits.page.searchCategory,

      hits.isExit,
      hits.customDimensions.value,
      hits.isEntrance,

      -- Ecommerce
      hits.transaction.transactionId,
      hits.transaction.transactionRevenue,
      hits.transaction.transactionTax,
      hits.transaction.transactionShipping,
      hits.transaction.affiliation,
      hits.transaction.currencyCode,
      hits.transaction.localTransactionRevenue,
      hits.transaction.localTransactionTax,
      hits.transaction.localTransactionShipping,
      hits.transaction.transactionCoupon,
      hits.item.transactionId,
      hits.item.productName,
      hits.item.productCategory,
      hits.item.productSku,
      hits.item.itemQuantity,
      hits.item.itemRevenue,
      hits.item.currencyCode,
      hits.item.localItemRevenue,

      -- Enhanced Ecommerce
      hits.eCommerceAction.action_type,
      hits.eCommerceAction.step,
      hits.eCommerceAction.option,

      hits.product.productSKU,
      hits.product.v2ProductName,
      hits.product.v2ProductCategory,
      hits.product.productVariant,
      hits.product.productBrand,
      hits.product.productRevenue,
      hits.product.localProductRevenue,
      hits.product.productPrice,
      hits.product.localProductPrice,
      hits.product.productQuantity,
      hits.product.productRefundAmount,
      hits.product.localProductRefundAmount,
      hits.product.isImpression,
      hits.refund.refundAmount,
      hits.refund.localRefundAmount,

      -- Promotion
      hits.promotion.promoId,
      hits.promotion.promoName,
      hits.promotion.promoCreative,
      hits.promotion.promoPosition,

      -- Mobile App
      hits.appInfo.landingScreenName,
      hits.appInfo.exitScreenName,

      -- Events
      hits.eventInfo.eventCategory,
      hits.eventInfo.eventAction,
      hits.eventInfo.eventLabel,
      hits.eventInfo.eventValue
    FROM
       (TABLE_DATE_RANGE([{ga_project_id}:{ga_dataset_id}.{ga_sessions_table_prefix}], TIMESTAMP('{date_start}'), TIMESTAMP('{date_end}')))
    WHERE hits.type = 'PAGE'
    """,
    "bouncesByDimensions": """
    SELECT * FROM [{ga_project_id}:{ga_dataset_id}.bounces_by_dimensions]
    """,
    "dailyAggregates": """
    SELECT * FROM [{ga_project_id}:{ga_dataset_id}.daily_aggregates]
    """
}

GA_PROJECT_ID = "nice-road-184014"
GA_DATASET_ID = "109512292"
GA_SESSIONS_TABLE_PREFIX = "ga_sessions_"


def get_sql(query_type, date_start, date_end):
    """
    Returns the sql for the requested query type.
    """
    return __QUERIES_BY_TYPE__[query_type].format(date_start=date_start, date_end=date_end, ga_project_id=GA_PROJECT_ID, ga_dataset_id=GA_DATASET_ID, ga_sessions_table_prefix=GA_SESSIONS_TABLE_PREFIX)
