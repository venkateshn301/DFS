import argparse
import httplib2
import pprint
import dmd_dsapi_setup
import dmd_dsapi_reports_config as config
from googleapiclient import http
from apiclient.discovery import build
from oauth2client import GOOGLE_TOKEN_URI
from oauth2client.client import OAuth2Credentials


def generate_columns(service):
    """
    """
    response = service.savedColumns().list(agencyId=config.AGENCY_ID,
                                           advertiserId=config.ADVERTISER_ID).execute()
    pprint.pprint(response)


if __name__ == '__main__':
    
    service = dmd_dsapi_setup.setup(None)
    generate_columns(service)
