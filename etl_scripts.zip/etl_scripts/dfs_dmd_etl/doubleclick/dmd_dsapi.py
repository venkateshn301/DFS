import argparse
import httplib2
import pprint
import io
import os
import sys
import time
from datetime import date, timedelta
import random
import dmd_dsapi_setup
import dmd_dsapi_reports_config
from googleapiclient import http
from apiclient.discovery import build
from oauth2client import GOOGLE_TOKEN_URI
from oauth2client.client import OAuth2Credentials

# Chunk size to use when downloading report files. Defaults to 32MB.
CHUNK_SIZE = 32 * 1024 * 1024

# The following values control retry behavior while the report is processing.
# Minimum amount of time between polling requests. Defaults to 10 seconds.
MIN_RETRY_INTERVAL = 10
# Maximum amount of time between polling requests. Defaults to 10 minutes.
MAX_RETRY_INTERVAL = 10 * 60
# Maximum amount of time to spend polling. Defaults to 1 hour.
MAX_RETRY_ELAPSED_TIME = 60 * 60

def run_report(report_type, report_id):
    # Wait for the report file to finish processing.
    # An exponential backoff strategy is used to conserve request quota.
    sleep = 0
    start_time = time.time()
    while True:
      report_file = service.reports().get(reportId = report_id).execute()

      status = report_file['isReportReady']
      if status is True:
        print('File status is %s, ready to download.' % status)
        get_report(report_type, report_id, 0)
        return
      elif time.time() - start_time > MAX_RETRY_ELAPSED_TIME:
        print('File processing deadline exceeded.')
        return

      sleep = next_sleep_interval(sleep)
      print('File status is %s, sleeping for %d seconds.' % (status, sleep))
      time.sleep(sleep)

def next_sleep_interval(previous_sleep_interval):
  """Calculates the next sleep interval based on the previous."""
  min_interval = previous_sleep_interval or MIN_RETRY_INTERVAL
  max_interval = previous_sleep_interval * 3 or MIN_RETRY_INTERVAL
  return min(MAX_RETRY_INTERVAL, random.randint(min_interval, max_interval))

def generate_file_name(report_type, report_file):
  """Generates a report file name based on the file metadata."""
  # If no filename is specified, use the file ID instead.
  file_name = report_type
  extension = '.csv' if report_file['request']['downloadFormat'] == 'csv' else '.xml'
  return file_name + extension

def get_report(report_type, report_id, fragment):
    # Retrieve the file metadata.
    report_file = service.reports().get(reportId = report_id).execute()

    if report_file['isReportReady'] is True:
      # Prepare a local file to download the report contents to.
      out_file = io.FileIO(generate_file_name(report_type, report_file), mode='wb')

      # Create a get request.
      request = service.reports().getFile_media(reportId=report_id, reportFragment = fragment)

      # Create a media downloader instance.
      # Optional: adjust the chunk size used when downloading the file.
      downloader = http.MediaIoBaseDownload(out_file, request,
                                            chunksize=CHUNK_SIZE)

      # Execute the get request and download the file.
      download_finished = False
      while download_finished is False:
        _, download_finished = downloader.next_chunk()

      print('File %s downloaded to %s'
            % (report_file['id'], os.path.realpath(out_file.name)))
      

def generate_report(service, report_type, date_start, date_end):
  """Generate and stores DS API report.
  """

  report_request = service.reports().request(
    body = dmd_dsapi_reports_config.get_report_body(report_type, date_start, date_end)
  ).execute();

  return report_request['id']


if __name__ == '__main__':
  dafault_date = (date.today() - timedelta(1)).strftime("%Y-%m-%d")
  parser = argparse.ArgumentParser(description='DoubleClick Search API Reports Service.')
  parser.add_argument('--report_type', dest='report_type', action='store',
                      help=('Specifies the report type to generate the report for. E.g. account or campaign')
                      , default='account')
  parser.add_argument('--date_start', dest='date_start', action='store',
                           help=('Specifies the start date for the report. E.g. 2017-11-15'), default=dafault_date)
  parser.add_argument('--date_end', dest='date_end', action='store',
                           help=('Specifies the end date for the report. E.g. 2017-11-20'), default=dafault_date)
    
  args = parser.parse_args()

  service = dmd_dsapi_setup.setup(None)
  report_id = generate_report(service, args.report_type, args.date_start, args.date_end)
  run_report(args.report_type, report_id)