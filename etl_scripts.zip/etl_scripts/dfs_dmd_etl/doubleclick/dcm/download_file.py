#!/usr/bin/python

"""This example illustrates how to download a report file."""

import argparse
import io
import os
import sys

import dfareporting_utils
from googleapiclient import http
from oauth2client import client

# Chunk size to use when downloading report files. Defaults to 32MB.
CHUNK_SIZE = 32 * 1024 * 1024


def download_file(report_id, file_id):
  # Authenticate and construct service.
  service = dfareporting_utils.setup(None)

  try:
    # Retrieve the file metadata.
    report_file = service.files().get(reportId=report_id,
                                      fileId=file_id).execute()

    if report_file['status'] == 'REPORT_AVAILABLE':
      # Prepare a local file to download the report contents to.
      out_file = io.FileIO(generate_file_name(report_file), mode='wb')

      # Create a get request.
      request = service.files().get_media(reportId=report_id, fileId=file_id)

      # Create a media downloader instance.
      # Optional: adjust the chunk size used when downloading the file.
      downloader = http.MediaIoBaseDownload(out_file, request,
                                            chunksize=CHUNK_SIZE)

      # Execute the get request and download the file.
      download_finished = False
      while download_finished is False:
        _, download_finished = downloader.next_chunk()

      print('File %s downloaded to %s'
            % (report_file['id'], os.path.realpath(out_file.name)))

      return True

  except client.AccessTokenRefreshError:
    print ('The credentials have been revoked or expired, please re-run the '
           'application to re-authorize')


def generate_file_name(report_file):
  """Generates a report file name based on the file metadata."""
  # If no filename is specified, use the file ID instead.
  file_name = report_file['fileName'] or report_file['id']
  extension = '.csv' if report_file['format'] == 'CSV' else '.xml'
  return file_name + extension
