#!/usr/bin/python

"""This example illustrates how to get a list of all the files for a report."""

import sys
import dfareporting_utils
from oauth2client import client

def get_report_files(service, profile_id, report_id):

  # Authenticate and construct service.
  service = dfareporting_utils.setup()

  try:
    # Construct a get request for the specified report.
    request = service.reports().files().list(
        profileId=profile_id, reportId=report_id)

    report_files = []

    while True:
      # Execute request and print response.
      response = request.execute()

      print(response)

      for report_file in response['items']:
        print ('Report file with ID %s and file name "%s" has status %s.'
               % (report_file['id'], report_file['fileName'],
                  report_file['status']))
        report_files.append(report_file['id'])

      if response['items'] and response['nextPageToken']:
        request = service.reports().files().list_next(request, response)
      else:
        break

      return report_files

  except client.AccessTokenRefreshError:
    print ('The credentials have been revoked or expired, please re-run the '
           'application to re-authorize')