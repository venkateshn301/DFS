#!/usr/bin/python

"""This script is used for creating a DCM/DFA report."""

import argparse
import sys
from time import strftime
from datetime import date, timedelta

import dfareporting_utils
import get_report_config as config
import run_report as reports_runner
import download_file as report_downloader
from oauth2client import client
import googleapiclient

import pprint

dafault_date = (date.today() - timedelta(1)).strftime("%Y-%m-%d")


def main(args):

    # Authenticate and construct service.
    service = dfareporting_utils.setup(args)

    profile_id = config.DFA_PROFILE_ID

    report_type = args.report_type

    try:
        # Check if the report id exists
        report_id = config.get_report_id(report_type)
        if report_id is not None:
            report_data = service.reports().get(
                profileId=profile_id, reportId=report_id).execute()
            # pprint.pprint(report_data)
            # Create a new report resource to insert
            report = config.get_report_body(
                report_type, report_data, args.date_start, args.date_end)
            # pprint.pprint(report)

            # Construct the request.
            request = service.reports().update(profileId=profile_id,
                                               body=report, reportId=report_id)
        else:
            report = config.get_report_body(
                report_type, None, args.date_start, args.date_end)
            request = service.reports().insert(
                profileId=profile_id, body=report)

        # Execute request and print response.
        response = request.execute()

        print('Created %s report with ID %s and name "%s".'
              % (response['type'], response['id'], response['name']))

        report_file = reports_runner.run_report(profile_id, response['id'])
        if report_file is not None:
            report_downloader.download_file(response['id'], report_file)
        else:
            print('Couldn\'t get report file for the requested report id.')

    except client.AccessTokenRefreshError:
        print('The credentials have been revoked or expired, please re-run the '
              'application to re-authorize')

    except googleapiclient.errors.HttpError as err:
        pprint.pprint(err)


if __name__ == '__main__':
    # Declare command-line flags.
    argparser = argparse.ArgumentParser(add_help=False)
    argparser.add_argument('--report_type', dest='report_type', action='store',
                           help=('The type of the report to create a report for E.g. standard_display_uk'), default='standard_display_uk')
    argparser.add_argument('--date_start', dest='date_start', action='store',
                           help=('Specifies the start date for the report. E.g. 2017-11-15'), default=dafault_date)
    argparser.add_argument('--date_end', dest='date_end', action='store',
                           help=('Specifies the end date for the report. E.g. 2017-11-20'), default=dafault_date)
    args = argparser.parse_args()
    main(args)
