"""
"""

REPORT_DEFINITONS_BY_REPORT_TYPE = {
    "standard_display_uk": {
        'name': 'Standard Report for Display Ads UK',
        'type': 'STANDARD',
        'fileName': 'display_uk',
        'format': 'CSV',
        'criteria': {
            'dimensions': [{'name': 'dfa:date'}, {'name': 'dfa:campaign'}, {'name': 'dfa:site'}, {'name': 'dfa:advertiser'}, {'name': 'dfa:placement'}],
            'metricNames': ['dfa:clicks', 'dfa:costPerClick', 'dfa:clickRate', 'dfa:impressions', 'dfa:costPerActivity', 'dfa:revenuePerClick', 'dfa:revenuePerThousandImpressions', 'dfa:totalConversions', 'dfa:totalConversionsRevenue'],
            'dimensionFilters': [{'dimensionName': 'dfa:advertiser', 'id': '6522556'}],
            'activities': {'filters': [{'dimensionName': 'dfa:activity', 'id': '4365848'}, {'dimensionName': 'dfa:activity', 'id': '4495184'}, {'dimensionName': 'dfa:activity', 'id': '4366055'}], "metricNames": [  # List of names of floodlight activity metrics.
                "dfa:totalConversions",
            ], }
        },
    },
    "standard_display_ie": {
        'name': 'Standard Report for Display Ads IE',
        'type': 'STANDARD',
        'fileName': 'display_ie',
        'format': 'CSV',
        'criteria': {
            'dimensions': [{'name': 'dfa:date'}, {'name': 'dfa:campaign'}, {'name': 'dfa:site'}, {'name': 'dfa:advertiser'}, {'name': 'dfa:placement'}],
            'metricNames': ['dfa:clicks', 'dfa:costPerClick', 'dfa:clickRate', 'dfa:impressions', 'dfa:costPerActivity', 'dfa:revenuePerClick', 'dfa:revenuePerThousandImpressions', 'dfa:totalConversions', 'dfa:totalConversionsRevenue'],
            'dimensionFilters': [{'dimensionName': 'dfa:advertiser', 'id': '6700125'}],
            'activities': {'filters': [{'dimensionName': 'dfa:activity', 'id': '4366851'}], "metricNames": [  # List of names of floodlight activity metrics.
                "dfa:totalConversions",
            ], }
        }
    },
    "standard_email": {
        'name': 'Standard Report for Email Campaigns',
        'type': 'STANDARD',
        'fileName': 'email',
        'format': 'CSV',
        'criteria': {
            'dimensions': [{'name': 'dfa:date'}, {'name': 'dfa:campaign'}, {'name': 'dfa:site'}, {'name': 'dfa:advertiser'}, {'name': 'dfa:placement'}],
            'metricNames': ['dfa:clicks', 'dfa:costPerClick', 'dfa:clickRate', 'dfa:impressions', 'dfa:costPerActivity', 'dfa:revenuePerClick', 'dfa:revenuePerThousandImpressions', 'dfa:totalConversions', 'dfa:totalConversionsRevenue'],
            'dimensionFilters': [{'dimensionName': 'dfa:advertiser', 'id': '6544008'}],
            'activities': {'filters': [{'dimensionName': 'dfa:activity', 'id': '4365848'}, {'dimensionName': 'dfa:activity', 'id': '4495184'}, {'dimensionName': 'dfa:activity', 'id': '4366055'}], "metricNames": [  # List of names of floodlight activity metrics.
                "dfa:totalConversions",
            ], }
        }
    },
    "standard_social": {
        'name': 'Standard Report for Social Campaigns',
        'type': 'STANDARD',
        'fileName': 'social',
        'format': 'CSV',
        'criteria': {
            'dimensions': [{'name': 'dfa:date'}, {'name': 'dfa:campaign'}, {'name': 'dfa:site'}, {'name': 'dfa:advertiser'}, {'name': 'dfa:placement'}],
            'metricNames': ['dfa:clicks', 'dfa:costPerClick', 'dfa:clickRate', 'dfa:impressions', 'dfa:costPerActivity', 'dfa:revenuePerClick', 'dfa:revenuePerThousandImpressions', 'dfa:totalConversions', 'dfa:totalConversionsRevenue'],
            'dimensionFilters': [{'dimensionName': 'dfa:advertiser', 'id': '6542120'}],
            'activities': {'filters': [{'dimensionName': 'dfa:activity', 'id': '4365848'}, {'dimensionName': 'dfa:activity', 'id': '4495184'}, {'dimensionName': 'dfa:activity', 'id': '4366055'}], "metricNames": [  # List of names of floodlight activity metrics.
                "dfa:totalConversions",
            ], }
        }
    },
    "standard_all": {
        'name': 'Standard Report',
        'type': 'STANDARD',
        'fileName': 'standard',
        'format': 'CSV',
        'criteria': {
            'dimensions': [{'name': 'dfa:date'}, {'name': 'dfa:campaign'}, {'name': 'dfa:site'}, {'name': 'dfa:advertiser'}, {'name': 'dfa:placement'}],
            'metricNames': ['dfa:clicks', 'dfa:costPerClick', 'dfa:clickRate', 'dfa:impressions', 'dfa:costPerActivity', 'dfa:revenuePerClick', 'dfa:revenuePerThousandImpressions', 'dfa:totalConversions', 'dfa:totalConversionsRevenue'],
            'activities': {'filters': [{'dimensionName': 'dfa:activity', 'id': '4365848'}, {'dimensionName': 'dfa:activity', 'id': '4495184'}, {'dimensionName': 'dfa:activity', 'id': '4366055'}], "metricNames": [  # List of names of floodlight activity metrics.
                "dfa:totalConversions",
            ], }
        }
    }
}

REPORT_IDS_BY_REPORT_TYPE = {
    "standard_display_uk": "110926412",
    "standard_display_ie": "110925995",
    "standard_email": "110952223",
    "standard_social": "111059482",
    "standard_all": "111070946"
}

DFA_PROFILE_ID = 4210965


def get_report_body(report_type, report_data, date_start, date_end):
    """
    Get report body given the report type, report's meta data, start and end dates.
    """
    report_body = REPORT_DEFINITONS_BY_REPORT_TYPE[report_type]
    report_body['criteria']['dateRange'] = {
        'startDate': date_start,
        'endDate': date_end
    }
    report_id = get_report_id(report_type)
    if report_id is not None:
        report_body['ownerProfileId'] = report_data['ownerProfileId']
        report_body['lastModifiedTime'] = report_data['lastModifiedTime']
        report_body['accountId'] = report_data['accountId']
        report_body['id'] = report_data['id']

    return report_body


def get_report_id(report_type):
    """
    Get report id given the report type
    """
    return REPORT_IDS_BY_REPORT_TYPE[report_type]
