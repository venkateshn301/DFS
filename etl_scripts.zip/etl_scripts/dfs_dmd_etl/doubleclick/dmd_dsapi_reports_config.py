""" Configuration for DS API Reports.
"""

REPORT_COLUMNS_BY_REPORT_TYPE = {
    "keyword": [
        {"columnName": "date"},
        {"columnName": "account"},
        {"columnName": "campaign"},
        {"columnName": "campaignId"},
        {"columnName": "campaignStatus"},
        {"columnName": "keywordId"},
        {"columnName": "keywordMatchType"},
        {"columnName": "keywordText"},
        {"columnName": "keywordEngineId"},
        {"columnName": "keywordMaxCpc"},
        {"columnName": "effectiveKeywordMaxCpc"},
        {"columnName": "keywordLabels"},
        {"columnName": "effectiveLabels"},
        {"columnName": "avgCpc"},
        {"columnName": "avgCpm"},
        {"columnName": "avgPos"},
        {"columnName": "clicks"},
        {"columnName": "cost"},
        {"columnName": "ctr"},
        {"columnName": "impr"},
        {"columnName": "adWordsConversions"},
        {"columnName": "adWordsConversionValue"},
        {"columnName": "visits"},
        {"savedColumnName": "CPA"},
        {"savedColumnName": "AOV"},
        {"savedColumnName": "Calls"},
        {"savedColumnName": "CMBs"},
        {"savedColumnName": "Unique Lands"},
        {"savedColumnName": "Revenue"},
        {"savedColumnName": "Sales"},
        {"savedColumnName": "Store Locator"},
        {"savedColumnName": "Video Chat"},
        {"savedColumnName": "All Conversions"},
    ],

    "campaign": [
        {"columnName": "date"},
        {"columnName": "account"},
        {"columnName": "campaign"},
        {"columnName": "campaignId"},
        {"columnName": "campaignStatus"},
        {"columnName": "campaignLabels"},
        {"columnName": "campaignType"},
        {"columnName": "effectiveLabels"},
        {"columnName": "avgCpc"},
        {"columnName": "avgPos"},
        {"columnName": "clicks"},
        {"columnName": "cost"},
        {"columnName": "ctr"},
        {"columnName": "impr"},
        {"columnName": "adWordsConversions"},
        {"columnName": "adWordsConversionValue"},
        {"columnName": "visits"},
        {"savedColumnName": "CPA"},
        {"savedColumnName": "AOV"},
        {"savedColumnName": "Calls"},
        {"savedColumnName": "CMBs"},
        {"savedColumnName": "Unique Lands"},
        {"savedColumnName": "Revenue"},
        {"savedColumnName": "Sales"},
        {"savedColumnName": "Store Locator"},
        {"savedColumnName": "Video Chat"},
        {"savedColumnName": "All Conversions"},
        {"columnName": "searchImpressionShare"},
    ],

    "paidAndOrganic": [
        {"columnName": "accountType"},
        {"columnName": "accountId"},
        {"columnName": "campaign"},
        {"columnName": "campaignId"},
        {"columnName": "searchQuery"},
        {"columnName": "serpType"},
        {"columnName": "paidClicks"},
        {"columnName": "organicClicks"},
        {"columnName": "paidAndOrganicClicks"},
        {"columnName": "paidImpressions"},
        {"columnName": "organicQueries"},
        {"columnName": "paidAndOrganicQueries"},
        {"columnName": "paidCtr"},
        {"columnName": "organicCtr"},
        {"columnName": "paidAndOrganicCtr"},
        {"columnName": "paidAvgPos"},
        {"columnName": "organicAvgPos"},
        {"columnName": "paidCostPerClick"},
        {"columnName": "date"},
        {"columnName": "keywordText"}
    ],

    "productAdvertised": [
        {"columnName": "date"},
        {"columnName": "accountId"},
        {"columnName": "campaignId"},
        {"columnName": "productId", "productReportPerspective": "advertised"},
        {"columnName": "clicks"},
        {"columnName": "cost"},
        {"columnName": "ctr"},
        {"columnName": "impr"},
        {"savedColumnName": "Revenue"},
        {"savedColumnName": "Sales"},
        {"savedColumnName": "Store Locator"},
        {"savedColumnName": "All Conversions"},
    ],

    "account": [
        {"columnName": "date"},
        {"columnName": "account"},
        {"columnName": "accountEngineId"},
        {"columnName": "avgCpc"},
        {"columnName": "avgCpm"},
        {"columnName": "avgPos"},
        {"columnName": "clicks"},
        {"columnName": "cost"},
        {"columnName": "ctr"},
        {"columnName": "impr"},
        {"columnName": "adWordsConversions"},
        {"columnName": "adWordsConversionValue"},
        {"columnName": "visits"},
        {"savedColumnName": "CPA"},
        {"savedColumnName": "AOV"},
        {"savedColumnName": "Calls"},
        {"savedColumnName": "CMBs"},
        {"savedColumnName": "Unique Lands"},
        {"savedColumnName": "Revenue"},
        {"savedColumnName": "Sales"},
        {"savedColumnName": "Store Locator"},
        {"savedColumnName": "Video Chat"},
        {"columnName": "searchImpressionShare"},
    ]
}

REPORT_FILTERS_BY_REPORT_TYPE = {
    "keyword": [
        # {
        #     "column": {
        #         "columnName": "keywordText"
        #     },
        #     "operator": "in",
        #     "values": [
        #         "sofa",
        #         "sofas",
        #         "dfs"
        #     ]
        # },
        {
            "column": {
                "columnName": "effectiveLabels"
            },
            "operator": "containsElement",
            "values": [
                "Generics",
                "Brand",
            ]
        },
    ],
    "campaign": None,
    "account": None,
    "productAdvertised": None,
    "paidAndOrganic": None
}

DOWNLOAD_FORMAT = 'csv'
MAX_ROWS_PER_FILE = 10000000
STATISTICS_CURRENCY = 'agency'
AGENCY_ID = '20700000001141101'
ADVERTISER_ID = '21700000001384254'


def get_report_body(report_type, date_start, date_end):
    """Gets DS API Report Body given the report type, start and end dates
    """
    report_body = {
        "reportScope": {
            "agencyId": AGENCY_ID,
            "advertiserId": ADVERTISER_ID,
            #"engineAccountId": "700000001550491"
        },
        "reportType": report_type,
        "columns": REPORT_COLUMNS_BY_REPORT_TYPE[report_type],
        "downloadFormat": DOWNLOAD_FORMAT,
        "maxRowsPerFile": MAX_ROWS_PER_FILE,
        "statisticsCurrency": STATISTICS_CURRENCY,
        "timeRange": {
            "startDate": date_start,
            "endDate": date_end
        }
    }

    report_filters = REPORT_FILTERS_BY_REPORT_TYPE[report_type]

    if report_filters is not None:
        report_body["filters"] = report_filters

    return report_body
