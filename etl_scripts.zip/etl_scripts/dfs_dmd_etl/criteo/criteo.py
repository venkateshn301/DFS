from pycriteo import Client
from suds.sudsobject import asdict
import json
import dbmodel
import config

#TODO add credentials to environment variables
c = Client(config.cr_username, config.cr_password, config.cr_token)
c.logging(log_level='DEBUG')
campaigns = c.getCampaigns({'campaignIDs': []})
budgets = c.getBudgets({"budgetIDs": []})

def recursive_asdict(d):
    """Convert Suds object into serializable format."""
    out = {}
    for k, v in asdict(d).items():
        if hasattr(v, '__keylist__'):
            out[k] = recursive_asdict(v)
        elif isinstance(v, list):
            out[k] = []
            for item in v:
                if hasattr(item, '__keylist__'):
                    out[k].append(recursive_asdict(item))
                else:
                    out[k].append(item)
        else:
            out[k] = v
    return out


def suds_to_json(data):
    return json.dumps(recursive_asdict(data))

cam = recursive_asdict(campaigns)['campaign']
campn = [{k: v for k, v in d.items() if k != 'campaignBid'} for d in cam]
bdgt = recursive_asdict(budgets)['budget']

for j in campn:
    if 'endDate' not in j:
        j['endDate'] = None

print(campn)

dbmodel.insert_data(dbmodel.staging_criteo_campaigns, campn)
dbmodel.insert_data(dbmodel.staging_criteo_budget, bdgt)
