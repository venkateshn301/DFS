from sqlalchemy import create_engine, Table, Column, Integer, String, MetaData, DECIMAL, Date, ForeignKey
from sqlalchemy.sql import select
import config

engine = create_engine(config.cr_connection_string)
#engine = create_engine('postgresql://masteruser:Beyond2017!@dev-extractor-db.cnimcclfnoqr.eu-west-1.rds.amazonaws.com/extractordb')
metadata = MetaData()

staging_criteo_budget = Table('staging_criteo_budget', metadata,
                              Column('budgetID', Integer, primary_key=True),
                              Column('budgetName', String(500)),
                              Column('totalAmount', DECIMAL),
                              Column('remainingBudget',DECIMAL ),
                              Column('remainingBudgetUpdated', Date),
                              schema='dmd_staging'
                              )

staging_criteo_campaigns = Table('staging_criteo_campaigns', metadata,
                                 Column('campaignID', Integer, primary_key=True),
                                 Column('campaignName',String(500)),
                                 Column('status', String(255)),
                                 Column('budgetID', Integer),
                                 Column('endDate', Date),
                                 Column('categoryBids',String(255)),
                                 Column('remainingDays', Integer),
                                 schema='dmd_staging'
                                 )

staging_brightedge_account = Table('staging_brightedge_account', metadata,
                                   Column('id',Integer, primary_key=True),
                                   Column('account', String(255)),
                                   schema='dmd_staging'
                                   )

staging_brightedge_competitors = Table('staging_brightedge_competitors', metadata,
                                       Column('id',Integer,primary_key=True),
                                       Column('account_id', Integer),
                                       Column('domain', String(255)),
                                       schema='dmd_staging'
                                       )

#metadata.create_all(engine)
conn = engine.connect()


def insert_data(table_name, data_dict):

    if table_name.exists(engine):
        conn.execute(table_name.delete())
    else:
        table_name.create(engine)

    conn.execute(table_name.insert(), data_dict)


def select_data(table_name):

    return conn.execute(select([table_name]))
